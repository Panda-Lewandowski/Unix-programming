sudo apt-get install gcc build-essential

sudo apt-get install linux-headers-`uname -r`